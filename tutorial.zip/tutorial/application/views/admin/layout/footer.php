<div class="clearfix"></div>
    <footer>Web Design by Irfan Saputra - &copy; by Irfan Saputra 2020 </footer>    
</div>
</body>
</html>