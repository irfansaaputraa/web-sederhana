<header>
	  <div class="akun"><a href="<?php echo base_url();?>admin/dasbor/config" title="Update konfigurasi"><img src="<?php echo base_url();?>asset/images/javawebmedia.png" width="16" height="16"> Sistem Informasi Irfan Saputra</a></div>
	  <div class="akun"><a href="<?php echo base_url();?>admin/update" title="Update profil"><img src="<?php echo base_url();?>asset/images/img/user_red.png" width="16" height="16"> Irfan Saputra</a></div>
      <div class="akun"><a href="<?php echo base_url();?>admin/logout" title="Logout disini"><img src="<?php echo base_url();?>asset/images/img/delete.png" width="16" height="16"> Logout</a></div>
	  <div class="home"><a href="<?php echo base_url();?>" title="Beranda"><img src="<?php echo base_url();?>asset/images/img/house_go.png" width="16" height="16"> Beranda</a></div>
  </header>