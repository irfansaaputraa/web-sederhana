<div class="konten">
<h1>Halaman dasbor Code Igniter</h1>
</div>