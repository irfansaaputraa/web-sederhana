<header>
	<div id="logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url();
?>asset/images/i.jpg" width="400" height="400"></a></div>
	<div id="nama"><span class="nama">PEMROGRAMAN WEB</span><br>
	<span class="aipni">IRFAN SAPUTRA</span></div>
	</header>
	<nav>
		<ul>
		<li><a href="<?php echo base_url(); ?>">Home</a></li>
		<li><a href="<?php echo base_url(); ?>"target="_blank">About us</a></li>
		<li><a href="<?php echo base_url(); ?>admin/login">Login</a></li>
		<li><a href="<?php echo base_url(); ?>kontak">Kontak</a></li>
		</ul>
		</nav>